import processing.core.PApplet;

public class Sketch extends PApplet {

  public void settings() {
    size(640,360);

  }
    //sky
    float skyR = 135;
    float skyG = 206;
    float skyB = 235;

    //sun
    float sunX = 450;

    //moon
    float moonX = 1050;
 

  public void draw() {
    //clear out old frames
    background(skyR,skyG,skyB);
    skyR = skyR - 2;
    skyG = skyG - 2;
    skyB = skyB - 2;

    //sun
    fill(255, 255, 0);
    ellipse(sunX,75,80,80);
    sunX = sunX - 10;

    //moon
    fill(255);
    ellipse(moonX,75,80,80);
    moonX = moonX - 10;

    //ground
    fill(107,208,76);
    rect(0,250,640,360);

    //path
    fill(190,155,123);
    rect(0,280,900,35);

    //tree
    fill(111,78,55);
    rect(80,165,10,100);
    fill(53,136,86);
    ellipse(85,150,100,95);

    //loop the animation
    if (moonX < 0) {
      sunX = 450;
      sunX = sunX - 10;
      moonX = 990;
      moonX = moonX - 10;
      skyR = 135;
      skyG = 206;
      skyB = 235;
      skyR = skyR + 2;
      skyG = skyG + 2;
      skyB = skyB + 2;
    }
    
  }

}